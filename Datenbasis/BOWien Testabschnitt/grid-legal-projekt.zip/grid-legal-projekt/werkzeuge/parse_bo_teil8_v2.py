"""
Parser v0.2 für Teil 8 der Bauordnung Wien.
Kombiniert die Textextraktion mit den manuellen Anreicherungen.
"""
import sys
sys.path.insert(0, '/home/claude/grid-legal-projekt/werkzeuge')

import json
from pathlib import Path

# Importiere bestehende Parser-Funktionen
from parse_bo_teil8 import (
    normalize_text,
    load_teil_8,
    split_into_paragraphs,
    split_paragraph_into_absaetze,
    PARAGRAPH_UEBERSCHRIFTEN,
    KATEGORIE_MAPPING,
    PLANUNGSPHASE_MAPPING,
)

# Importiere die manuellen Anreicherungen
from anreicherungen_teil8 import ANREICHERUNGEN


# =============================================================================
# PLATZHALTER-GENERATOREN (unverändert)
# =============================================================================

def generate_platzhalter_headline(absatz_text: str) -> str:
    snippet = absatz_text[:90].strip()
    if len(absatz_text) > 90:
        last_space = snippet.rfind(' ')
        if last_space > 40:
            snippet = snippet[:last_space]
        snippet += " …"
    return f"[PLATZHALTER-HEADLINE] {snippet}"


def generate_platzhalter_erklaerung(absatz_text: str) -> str:
    return (
        "[PLATZHALTER-ERKLÄRUNG für Architekten] "
        "Diese Erklärung wird später durch eine LLM-generierte, "
        "architektengerechte Umformulierung der Vorschrift ersetzt. "
        f"Der Originaltext umfasst {len(absatz_text)} Zeichen."
    )


# =============================================================================
# RECHTSSATZ-OBJEKT MIT ANREICHERUNGEN
# =============================================================================

import re

def build_rechtssatz(paragraph_nummer, absatz_nummer, absatz_text,
                     ueberschrift, is_entfallen=False):
    """Erzeugt das angereicherte Rechtssatz-Objekt."""
    suffix = f"-abs{absatz_nummer}" if absatz_nummer else ""
    rid = f"bo-wien-para-{paragraph_nummer}{suffix}"

    kat = KATEGORIE_MAPPING.get(paragraph_nummer, {})
    phase = PLANUNGSPHASE_MAPPING.get(paragraph_nummer)

    # Hole die manuellen Anreicherungen
    anreicherung = ANREICHERUNGEN.get(rid, {})

    # Headline: manuelle hat Vorrang vor Platzhalter
    if "headline_manuell" in anreicherung:
        headline = anreicherung["headline_manuell"]
    elif is_entfallen:
        headline = "(Paragraph entfallen)"
    else:
        headline = generate_platzhalter_headline(absatz_text)

    # Erklärung: weiterhin Platzhalter (wird später per LLM ersetzt)
    erklaerung = (
        generate_platzhalter_erklaerung(absatz_text)
        if not is_entfallen else "Dieser Paragraph wurde aufgehoben."
    )

    rechtssatz = {
        # === Identifikation ===
        "id": rid,
        "quelle": "Bauordnung für Wien",
        "quelle_kurz": "BO Wien",
        "quelle_fassung": "11.03.2026",

        # === Strukturelle Verortung ===
        "paragraph": paragraph_nummer,
        "absatz": absatz_nummer,
        "ziffer": None,
        "fundstelle": (
            f"§ {paragraph_nummer}"
            + (f" Abs. {absatz_nummer}" if absatz_nummer else "")
        ),
        "paragraph_ueberschrift": ueberschrift,

        # === Inhalt ===
        "headline": headline,
        "erklaerung": erklaerung,
        "originaltext": absatz_text,

        # === Kategorisierung ===
        "hauptkategorie": kat.get("hauptkategorie"),
        "unterkategorie": kat.get("unterkategorie"),
        "unterkategorie_label": kat.get("label"),

        # === Planungsphase ===
        "planungsphase": phase,

        # === Filter-Logik (jetzt befüllt!) ===
        "bedingungen": anreicherung.get("bedingungen", [{"typ": "immer"}]),
        "varianten": anreicherung.get("varianten", []),
        "anforderung": anreicherung.get("anforderung"),
        "querverweise": anreicherung.get("querverweise", []),

        # === Anwender-Hinweise (im UI anzeigen) ===
        "hinweise": anreicherung.get("hinweise", []),

        # === Prüfhinweise für manuelle Nachbearbeitung (intern) ===
        "pruefhinweise": anreicherung.get("pruefhinweise", []),

        # === Status ===
        "is_entfallen": is_entfallen,
        "status": anreicherung.get("status", "platzhalter_generiert"),
    }
    return rechtssatz


# =============================================================================
# MAIN
# =============================================================================

def main():
    raw = load_teil_8()
    normalized = normalize_text(raw)

    # Entferne alles vor dem ersten §
    first_para = re.search(r'§\s+\d+[a-z]?\.', normalized)
    if first_para:
        normalized = normalized[first_para.start():]

    paragraphen = split_into_paragraphs(normalized)

    rechtssaetze = []
    for p in paragraphen:
        absaetze = split_paragraph_into_absaetze(p["body"])
        for a in absaetze:
            rs = build_rechtssatz(
                paragraph_nummer=p["nummer"],
                absatz_nummer=a["nummer"],
                absatz_text=a["text"],
                ueberschrift=p["ueberschrift"],
                is_entfallen=a.get("is_entfallen", False),
            )
            rechtssaetze.append(rs)

    # Statistiken zur Anreicherung
    mit_bedingungen = sum(1 for rs in rechtssaetze
                          if rs["bedingungen"] and rs["bedingungen"] != [{"typ": "immer"}])
    mit_varianten = sum(1 for rs in rechtssaetze if rs["varianten"])
    mit_anforderung = sum(1 for rs in rechtssaetze if rs["anforderung"])
    mit_pruefhinweisen = sum(1 for rs in rechtssaetze if rs["pruefhinweise"])
    manuelle_headlines = sum(1 for rs in rechtssaetze
                              if not rs["headline"].startswith("[PLATZHALTER"))

    output = {
        "meta": {
            "schema_version": "0.2",
            "quelle": "Bauordnung für Wien",
            "quelle_kurz": "BO Wien",
            "fassung": "11.03.2026",
            "teil_nummer": 8,
            "teil_titel": "Bauliche Ausnützbarkeit der Bauplätze",
            "paragraphen_range": "§§ 75–86",
            "anzahl_rechtssaetze": len(rechtssaetze),
            "generiert_von": "Grid.legal Parser v0.2",
            "statistik_anreicherung": {
                "manuelle_headlines": manuelle_headlines,
                "mit_spezifischen_bedingungen": mit_bedingungen,
                "mit_varianten": mit_varianten,
                "mit_quantitativer_anforderung": mit_anforderung,
                "mit_pruefhinweisen": mit_pruefhinweisen,
            },
            "hinweis": (
                "Bedingungen, Varianten und Anforderungen sind manuell "
                "interpretiert und müssen von einer Fachperson (Architekt/Jurist) "
                "vor Produktivsetzung geprüft werden. Siehe Feld 'pruefhinweise' "
                "pro Rechtssatz."
            ),
        },
        "paragraphen_uebersicht": [
            {
                "nummer": p["nummer"],
                "ueberschrift": p["ueberschrift"],
                "anzahl_absaetze": sum(
                    1 for rs in rechtssaetze if rs["paragraph"] == p["nummer"]
                ),
            }
            for p in paragraphen
        ],
        "rechtssaetze": rechtssaetze,
    }

    return output


if __name__ == "__main__":
    result = main()
    output_path = Path("/home/claude/grid-legal-projekt/gesetzestexte/bauordnung-wien/bo-wien-teil-08.json")
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)

    print(f"✓ Datei geschrieben: {output_path}")
    print(f"\n  Rechtssätze: {len(result['rechtssaetze'])}")
    stat = result['meta']['statistik_anreicherung']
    print(f"\n  Anreicherungs-Statistik:")
    print(f"    Manuelle Headlines:          {stat['manuelle_headlines']} von {len(result['rechtssaetze'])}")
    print(f"    Mit spezifischen Bedingungen: {stat['mit_spezifischen_bedingungen']}")
    print(f"    Mit Varianten:                {stat['mit_varianten']}")
    print(f"    Mit quantitativer Anforderung: {stat['mit_quantitativer_anforderung']}")
    print(f"    Mit Prüfhinweisen:            {stat['mit_pruefhinweisen']}")
