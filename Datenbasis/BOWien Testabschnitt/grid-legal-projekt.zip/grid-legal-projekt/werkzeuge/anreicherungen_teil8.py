"""
Manuell kuratierte Anreicherungen für Teil 8 der BO Wien.

Für jeden Rechtssatz werden hier Bedingungen, Varianten, Anforderungen
und Querverweise definiert. Unsicherheiten sind als pruefhinweise markiert.

WICHTIG: Dies ist eine *Interpretation* des Gesetzestexts durch einen LLM.
Vor Produktivsetzung MUSS jedes Objekt von einer Fachperson (Architekt/Jurist)
geprüft werden.

Stand: Mittlere Komplexität, Hauptparameter abgedeckt.
"""

# Die Keys sind die Rechtssatz-IDs (z.B. "bo-wien-para-75-abs1").
# Jeder Value ist ein dict mit optionalen Feldern:
#   - bedingungen: Liste von Bedingungsobjekten
#   - varianten: Liste von Varianten
#   - anforderung: Schwellenwert-Objekt
#   - querverweise: Liste von Verweisen
#   - pruefhinweise: Liste von Hinweisen für manuelle Prüfung
#   - headline_manuell: Überschreibt die automatische Headline
#   - status: Bearbeitungsstatus

ANREICHERUNGEN = {
    # =====================================================================
    # § 75 — BAUKLASSENEINTEILUNG, ZULÄSSIGE GEBÄUDEHÖHE
    # =====================================================================

    "bo-wien-para-75-abs1": {
        "headline_manuell": "Bauklassen bestimmen die Gebäudehöhe in Wohn- und Mischgebieten",
        "bedingungen": [
            {
                "parameter": "widmung",
                "operator": "ist_eines_von",
                "werte": ["wohngebiet", "gemischtes_baugebiet"],
            }
        ],
        "anforderung": {
            "typ": "prosa",
            "text": "Die Bauklasseneinteilung (I–VI) legt die zulässige Gebäudehöhe fest.",
        },
        "status": "inhalte_pruefen",
    },

    "bo-wien-para-75-abs2": {
        "headline_manuell": "Mindest- und Höchsthöhen je Bauklasse (I bis V)",
        "bedingungen": [
            {
                "parameter": "widmung",
                "operator": "ist_eines_von",
                "werte": ["wohngebiet", "gemischtes_baugebiet"],
            }
        ],
        "hinweise": [
            "Abweichende Gebäudehöhen sind nach Abs. 4–6, § 81 und Bebauungsplan möglich.",
        ],
        "varianten": [
            {
                "wenn": {"parameter": "bauklasse", "operator": "ist", "wert": "BK_I"},
                "headline": "Bauklasse I: Gebäudehöhe 2,5 – 9 m",
                "anforderung": {"typ": "gebaeudehoehe", "min": 2.5, "max": 9, "einheit": "m"},
            },
            {
                "wenn": {"parameter": "bauklasse", "operator": "ist", "wert": "BK_II"},
                "headline": "Bauklasse II: Gebäudehöhe 2,5 – 12 m",
                "anforderung": {"typ": "gebaeudehoehe", "min": 2.5, "max": 12, "einheit": "m"},
            },
            {
                "wenn": {"parameter": "bauklasse", "operator": "ist", "wert": "BK_III"},
                "headline": "Bauklasse III: Gebäudehöhe 9 – 16 m",
                "anforderung": {"typ": "gebaeudehoehe", "min": 9, "max": 16, "einheit": "m"},
            },
            {
                "wenn": {"parameter": "bauklasse", "operator": "ist", "wert": "BK_IV"},
                "headline": "Bauklasse IV: Gebäudehöhe 12 – 21 m",
                "anforderung": {"typ": "gebaeudehoehe", "min": 12, "max": 21, "einheit": "m"},
            },
            {
                "wenn": {"parameter": "bauklasse", "operator": "ist", "wert": "BK_V"},
                "headline": "Bauklasse V: Gebäudehöhe 16 – 26 m",
                "anforderung": {"typ": "gebaeudehoehe", "min": 16, "max": 26, "einheit": "m"},
            },
        ],
        "querverweise": [
            {"ref_id": "bo-wien-para-81", "ref_text": "§ 81", "beschreibung": "Bemessung der Gebäudehöhe"}
        ],
        "status": "inhalte_pruefen",
    },

    "bo-wien-para-75-abs3": {
        "headline_manuell": "Bauklasse VI: Mindesthöhe 21 m, Höchstwert laut Bebauungsplan",
        "bedingungen": [
            {"parameter": "bauklasse", "operator": "ist", "wert": "BK_VI"}
        ],
        "anforderung": {
            "typ": "gebaeudehoehe",
            "min": 21,
            "einheit": "m",
            "zusatz": "Höchstwert ist dem Bebauungsplan zu entnehmen.",
        },
        "hinweise": [
            "Bei Bauklasse VI muss der Bebauungsplan die einzuhaltenden Gebäudehöhen innerhalb zweier Grenzmaße festsetzen.",
        ],
        "status": "inhalte_pruefen",
    },

    "bo-wien-para-75-abs4": {
        "headline_manuell": "Gebäudehöhe an Fluchtlinien: Abhängigkeit vom Fluchtlinien-Abstand",
        "bedingungen": [
            {"parameter": "bauplatz_an_fluchtlinie", "operator": "ist", "wert": "ja"}
        ],
        "varianten": [
            {
                "wenn": {"parameter": "bauklasse", "operator": "ist_eines_von", "werte": ["BK_I", "BK_II"]},
                "headline": "BK I / II: Fluchtlinienabstand + 2 m",
                "anforderung": {"typ": "prosa", "text": "Gebäudehöhe = Fluchtlinienabstand + 2 m"},
            },
            {
                "wenn": {"parameter": "bauklasse", "operator": "ist", "wert": "BK_III"},
                "headline": "BK III: Fluchtlinienabstand + 3 m",
                "anforderung": {"typ": "prosa", "text": "Gebäudehöhe = Fluchtlinienabstand + 3 m"},
            },
            {
                "wenn": {"parameter": "bauklasse", "operator": "ist", "wert": "BK_IV"},
                "headline": "BK IV: Fluchtlinienabstand + 3 m (bis 15 m) bzw. + 4 m (ab 15 m)",
                "anforderung": {"typ": "prosa", "text": "Fluchtlinienabstand bis 15 m: +3 m · ab 15 m: +4 m"},
            },
            {
                "wenn": {"parameter": "bauklasse", "operator": "ist_eines_von", "werte": ["BK_V", "BK_VI"]},
                "headline": "BK V / VI: Doppeltes Maß des Fluchtlinien-Abstandes",
                "anforderung": {"typ": "prosa", "text": "Gebäudehöhe = 2 × Fluchtlinienabstand"},
            },
        ],
        "pruefhinweise": [
            "PRÜFEN: Spezialfälle für ungleichen Abstand und unterschiedliche Bauklassen auf gegenüberliegenden Seiten sind hier nicht als Varianten abgebildet — stehen nur im Originaltext."
        ],
        "status": "inhalte_pruefen",
    },

    "bo-wien-para-75-abs4a": {
        "headline_manuell": "Ausnahme von Abs. 4 bei fehlender Gegenüber-Bebauung oder städtebaulichen Schwerpunkten",
        "bedingungen": [
            {"parameter": "bauplatz_an_fluchtlinie", "operator": "ist", "wert": "ja"}
        ],
        "pruefhinweise": [
            "PRÜFEN: Komplexe Ausnahmeregel — sollte später fein-granular aufgeteilt werden."
        ],
        "status": "inhalte_pruefen",
    },

    "bo-wien-para-75-abs4b": {
        "headline_manuell": "Wenn Gebäude nicht an Fluchtlinie: Abstand zur gegenüberliegenden Fluchtlinie maßgeblich",
        "bedingungen": [
            {"parameter": "bauplatz_an_fluchtlinie", "operator": "ist_nicht", "wert": "ja"}
        ],
        "status": "inhalte_pruefen",
    },

    "bo-wien-para-75-abs5": {
        "headline_manuell": "Eckbauplätze: Höhere Front darf auf bis zu 15 m auch an der anderen Hauptfront genutzt werden",
        "bedingungen": [{"typ": "immer"}],
        "anforderung": {"typ": "abstand", "max": 15, "einheit": "m", "bezug": "hauptfront_laenge"},
        "pruefhinweise": [
            "PRÜFEN: Dies ist nur anwendbar bei Eckbauplätzen — ggf. als eigener Wizard-Parameter ergänzen."
        ],
        "status": "inhalte_pruefen",
    },

    "bo-wien-para-75-abs6": {
        "headline_manuell": "Schutzzonen: Gebäudehöhe richtet sich nur nach Bebauungsplan bzw. Bauklasse",
        "bedingungen": [{"parameter": "in_schutzzone", "operator": "ist", "wert": "ja"}],
        "status": "inhalte_pruefen",
    },

    "bo-wien-para-75-abs7": {
        "headline_manuell": "Gartensiedlungsgebiete: Gebäudehöhe maximal 5,5 m",
        "bedingungen": [
            {"parameter": "widmung", "operator": "ist", "wert": "gartensiedlungsgebiet"},
            {"parameter": "bebauungsplan_abweichend", "operator": "ist_nicht", "wert": "ja"},
        ],
        "anforderung": {"typ": "gebaeudehoehe", "max": 5.5, "einheit": "m"},
        "status": "inhalte_pruefen",
    },

    "bo-wien-para-75-abs8": {
        "headline_manuell": "Erholungsgebiet / Badehütten: Höchstens 4 m über anschließendem Gelände",
        "bedingungen": [
            {"parameter": "widmung", "operator": "ist", "wert": "erholungsgebiet"},
            {"parameter": "bebauungsplan_abweichend", "operator": "ist_nicht", "wert": "ja"},
        ],
        "anforderung": {"typ": "gebaeudehoehe", "max": 4, "einheit": "m", "bezug": "tiefster_punkt_gelaende"},
        "pruefhinweise": [
            "PRÜFEN: Bezieht sich nur auf 'Grundflächen für Badehütten' — Unterkategorie der Erholungsgebiete."
        ],
        "status": "inhalte_pruefen",
    },

    "bo-wien-para-75-abs9": {
        "headline_manuell": "(Aufgehoben durch VfGH-Erkenntnis 2007)",
        "bedingungen": [],
        "anforderung": {"typ": "prosa", "text": "Durch VfGH-Erkenntnis vom 9.3.2007 aufgehoben."},
        "status": "inhalte_pruefen",
    },

    "bo-wien-para-75-abs10": {
        "headline_manuell": "Vor Inkrafttreten 1989 bewilligte Gebäude: Bestandsschutz bei Bauklasse-Änderungen",
        "bedingungen": [
            {"parameter": "neubau_oder_bestand", "operator": "ist", "wert": "bestand"}
        ],
        "status": "inhalte_pruefen",
    },

    "bo-wien-para-75-abs11": {
        "headline_manuell": "Bestandsschutz für Lauben- und Werkstattbauten in Gartensiedlungsgebieten",
        "bedingungen": [
            {"parameter": "neubau_oder_bestand", "operator": "ist", "wert": "bestand"},
            {"parameter": "widmung", "operator": "ist", "wert": "gartensiedlungsgebiet"},
        ],
        "status": "inhalte_pruefen",
    },

    # =====================================================================
    # § 76 — BAUWEISEN
    # =====================================================================

    "bo-wien-para-76-abs1": {
        "headline_manuell": "Zulässige Bauweisen im Bebauungsplan: offen / gekuppelt / Gruppe / geschlossen",
        "bedingungen": [{"typ": "immer"}],
        "anforderung": {
            "typ": "prosa",
            "text": "Bebauungsplan kann festlegen: offen, gekuppelt, offen oder gekuppelt, Gruppe, geschlossen."
        },
        "status": "inhalte_pruefen",
    },

    "bo-wien-para-76-abs2": {
        "headline_manuell": "Offene Bauweise: Gebäude freistehend, Mindestabstand nach § 79 Abs. 3",
        "bedingungen": [{"parameter": "bauweise", "operator": "ist", "wert": "offen"}],
        "querverweise": [
            {"ref_id": "bo-wien-para-79-abs3", "ref_text": "§ 79 Abs. 3", "beschreibung": "Mindestabstände zu Nachbargrenzen"}
        ],
        "status": "inhalte_pruefen",
    },

    "bo-wien-para-76-abs3": {
        "headline_manuell": "Gekuppelte Bauweise: Anbauen an gemeinsame Bauplatzgrenze",
        "bedingungen": [{"parameter": "bauweise", "operator": "ist", "wert": "gekuppelt"}],
        "status": "inhalte_pruefen",
    },

    "bo-wien-para-76-abs4": {
        "headline_manuell": "Wahl-Bauweise: Abweichen von offener/gekuppelter Bauweise erlaubt",
        "bedingungen": [
            {"parameter": "bauweise", "operator": "ist_eines_von", "werte": ["offen", "gekuppelt", "offen_oder_gekuppelt"]}
        ],
        "status": "inhalte_pruefen",
    },

    "bo-wien-para-76-abs5": {
        "headline_manuell": "Gruppenbauweise: Anbauen an mehrere Nachbargrundstücke",
        "bedingungen": [{"parameter": "bauweise", "operator": "ist", "wert": "gruppe"}],
        "status": "inhalte_pruefen",
    },

    "bo-wien-para-76-abs6": {
        "headline_manuell": "Gruppenbildung erfolgt durch Bebauungsplan",
        "bedingungen": [{"parameter": "bauweise", "operator": "ist", "wert": "gruppe"}],
        "status": "inhalte_pruefen",
    },

    "bo-wien-para-76-abs7": {
        "headline_manuell": "Offene / offen oder gekuppelte Bauweise: Anbaupflicht an Nachbargrenze in bestimmten Fällen",
        "bedingungen": [
            {"parameter": "bauweise", "operator": "ist_eines_von", "werte": ["offen", "offen_oder_gekuppelt"]}
        ],
        "pruefhinweise": ["PRÜFEN: Komplexe Zwangsregel zum Anbau — manuell validieren."],
        "status": "inhalte_pruefen",
    },

    "bo-wien-para-76-abs8": {
        "headline_manuell": "Geschlossene Bauweise: Gebäude stehen lückenlos an Baulinie",
        "bedingungen": [{"parameter": "bauweise", "operator": "ist", "wert": "geschlossen"}],
        "status": "inhalte_pruefen",
    },

    "bo-wien-para-76-abs9": {
        "headline_manuell": "Mehrere Gebäude auf einem Bauplatz: Abstände untereinander",
        "bedingungen": [
            {"parameter": "bauweise", "operator": "ist_eines_von", "werte": ["offen", "offen_oder_gekuppelt", "gekuppelt", "gruppe"]}
        ],
        "pruefhinweise": ["PRÜFEN: Hier stehen mehrere Regeln gebündelt — später eventuell aufteilen."],
        "status": "inhalte_pruefen",
    },

    "bo-wien-para-76-abs10": {
        "headline_manuell": "Wohn- und Mischgebiet: Bebaute Fläche max. ein Drittel (33,3 %) der Bauplatzfläche",
        "bedingungen": [
            {"parameter": "widmung", "operator": "ist_eines_von", "werte": ["wohngebiet", "gemischtes_baugebiet"]}
        ],
        "anforderung": {"typ": "flaeche", "max": 33.3, "einheit": "%", "bezug": "bauplatzflaeche"},
        "pruefhinweise": [
            "PRÜFEN: Geschäftsviertel und Betriebsbaugebiete sind ausgenommen.",
            "PRÜFEN: 33,3 % = 'ein Drittel' — Rundungsfrage klären.",
        ],
        "status": "inhalte_pruefen",
    },

    "bo-wien-para-76-abs10a": {
        "headline_manuell": "Bauplatzflächen über 500 m²: Mindestens 15 % frei von oberirdischer Bebauung",
        "bedingungen": [
            {"parameter": "widmung", "operator": "ist_eines_von", "werte": ["wohngebiet", "gemischtes_baugebiet"]}
        ],
        "anforderung": {"typ": "flaeche", "min": 15, "einheit": "%", "bezug": "bauplatzflaeche_ueber_500qm"},
        "status": "inhalte_pruefen",
    },

    "bo-wien-para-76-abs10b": {
        "headline_manuell": "Wohn- / Mischgebiet: Mindestens 50 % der Bauplatzfläche begrünt oder begrünbar",
        "bedingungen": [
            {"parameter": "widmung", "operator": "ist_eines_von", "werte": ["wohngebiet", "gemischtes_baugebiet"]}
        ],
        "pruefhinweise": ["PRÜFEN: Genaue Prozentangaben und Ausnahmen im Originaltext verifizieren."],
        "status": "inhalte_pruefen",
    },

    "bo-wien-para-76-abs11": {
        "headline_manuell": "Gartensiedlungsgebiet: Bebaute Fläche max. 150 m²",
        "bedingungen": [
            {"parameter": "widmung", "operator": "ist", "wert": "gartensiedlungsgebiet"},
            {"parameter": "bebauungsplan_abweichend", "operator": "ist_nicht", "wert": "ja"},
        ],
        "anforderung": {"typ": "flaeche", "max": 150, "einheit": "m²", "bezug": "bebaute_flaeche_absolut"},
        "status": "inhalte_pruefen",
    },

    "bo-wien-para-76-abs11a": {
        "headline_manuell": "Fahnen-Bauplätze: Verbindungsstreifen wird nicht auf Ausnützbarkeit angerechnet",
        "bedingungen": [{"typ": "immer"}],
        "status": "inhalte_pruefen",
    },

    "bo-wien-para-76-abs12": {
        "headline_manuell": "Erholungsgebiet / Badehütten: Eigene Regeln zur Ausnützbarkeit",
        "bedingungen": [
            {"parameter": "widmung", "operator": "ist", "wert": "erholungsgebiet"},
            {"parameter": "bebauungsplan_abweichend", "operator": "ist_nicht", "wert": "ja"},
        ],
        "status": "inhalte_pruefen",
    },

    "bo-wien-para-76-abs13": {
        "headline_manuell": "Überschreiten der baulichen Ausnützbarkeit nur mit ausdrücklicher Zulassung",
        "bedingungen": [{"typ": "immer"}],
        "status": "inhalte_pruefen",
    },

    # =====================================================================
    # § 77 — STRUKTUREN (städtebauliche Sonderregelungen)
    # =====================================================================
    # Alle Absätze von § 77 gelten nur, wenn der Bebauungsplan
    # städtebauliche Strukturen vorsieht. Das ist ein Sonderfall.

    "bo-wien-para-77-abs1": {
        "headline_manuell": "Strukturen: Abweichende Festlegungen im Bebauungsplan möglich",
        "bedingungen": [
            {"parameter": "bebauungsplan_abweichend", "operator": "ist", "wert": "ja"}
        ],
        "status": "inhalte_pruefen",
    },
    "bo-wien-para-77-abs2": {
        "headline_manuell": "Strukturen: Details zu Festlegungsmöglichkeiten",
        "bedingungen": [
            {"parameter": "bebauungsplan_abweichend", "operator": "ist", "wert": "ja"}
        ],
        "status": "inhalte_pruefen",
    },
    "bo-wien-para-77-abs3": {
        "headline_manuell": "Strukturen: Weitere Regelungen",
        "bedingungen": [
            {"parameter": "bebauungsplan_abweichend", "operator": "ist", "wert": "ja"}
        ],
        "status": "inhalte_pruefen",
    },
    "bo-wien-para-77-abs4": {
        "headline_manuell": "Strukturen: Weitere Regelungen",
        "bedingungen": [
            {"parameter": "bebauungsplan_abweichend", "operator": "ist", "wert": "ja"}
        ],
        "status": "inhalte_pruefen",
    },
    "bo-wien-para-77-abs5": {
        "headline_manuell": "Strukturen: Weitere Regelungen",
        "bedingungen": [
            {"parameter": "bebauungsplan_abweichend", "operator": "ist", "wert": "ja"}
        ],
        "status": "inhalte_pruefen",
    },
    "bo-wien-para-77-abs6": {
        "headline_manuell": "Strukturen: Weitere Regelungen",
        "bedingungen": [
            {"parameter": "bebauungsplan_abweichend", "operator": "ist", "wert": "ja"}
        ],
        "status": "inhalte_pruefen",
    },
    "bo-wien-para-77-abs7": {
        "headline_manuell": "Strukturen: Weitere Regelungen",
        "bedingungen": [
            {"parameter": "bebauungsplan_abweichend", "operator": "ist", "wert": "ja"}
        ],
        "pruefhinweise": [
            "PRÜFEN: § 77 insgesamt nicht im Detail analysiert — betrifft städtebauliche Sonderfälle. Bei Bedarf manuell nachbearbeiten."
        ],
        "status": "inhalte_pruefen",
    },

    # =====================================================================
    # § 78 — (entfallen)
    # =====================================================================
    "bo-wien-para-78": {
        "headline_manuell": "§ 78 — aufgehoben 2008",
        "bedingungen": [],
        "status": "final",
    },

    # =====================================================================
    # § 79 — VORGÄRTEN, ABSTANDSFLÄCHEN, GÄRTNERISCHE AUSGESTALTUNG
    # =====================================================================

    "bo-wien-para-79-abs1": {
        "headline_manuell": "Vorgarten: Tiefe in der Regel 5 m",
        "bedingungen": [
            {"parameter": "bebauungsplan_abweichend", "operator": "ist_nicht", "wert": "ja"}
        ],
        "anforderung": {"typ": "abstand", "min": 5, "einheit": "m", "bezug": "vorgarten_tiefe"},
        "hinweise": [
            "Abweichende Tiefen können im Bebauungsplan festgesetzt werden.",
        ],
        "status": "inhalte_pruefen",
    },

    "bo-wien-para-79-abs2": {
        "headline_manuell": "Vorgarten: Gärtnerische Ausgestaltung mit Bepflanzung",
        "bedingungen": [{"typ": "immer"}],
        "status": "inhalte_pruefen",
    },

    "bo-wien-para-79-abs3": {
        "headline_manuell": "Offene Bauweise: Abstände zu Nachbargrenzen je Bauklasse",
        "bedingungen": [{"parameter": "bauweise", "operator": "ist", "wert": "offen"}],
        "varianten": [
            {
                "wenn": {"parameter": "bauklasse", "operator": "ist_eines_von", "werte": ["BK_I", "BK_II"]},
                "headline": "BK I / II: Mindestabstand 6 m zur Nachbargrenze",
                "anforderung": {"typ": "abstand", "min": 6, "einheit": "m", "bezug": "nachbargrenze"},
            },
            {
                "wenn": {"parameter": "bauklasse", "operator": "ist", "wert": "BK_III"},
                "headline": "BK III: Mindestabstand 12 m",
                "anforderung": {"typ": "abstand", "min": 12, "einheit": "m", "bezug": "nachbargrenze"},
            },
            {
                "wenn": {"parameter": "bauklasse", "operator": "ist", "wert": "BK_IV"},
                "headline": "BK IV: Mindestabstand 14 m",
                "anforderung": {"typ": "abstand", "min": 14, "einheit": "m", "bezug": "nachbargrenze"},
            },
            {
                "wenn": {"parameter": "bauklasse", "operator": "ist", "wert": "BK_V"},
                "headline": "BK V: Mindestabstand 16 m",
                "anforderung": {"typ": "abstand", "min": 16, "einheit": "m", "bezug": "nachbargrenze"},
            },
            {
                "wenn": {"parameter": "bauklasse", "operator": "ist", "wert": "BK_VI"},
                "headline": "BK VI: Mindestabstand 20 m",
                "anforderung": {"typ": "abstand", "min": 20, "einheit": "m", "bezug": "nachbargrenze"},
            },
        ],
        "pruefhinweise": [
            "PRÜFEN: Im Originaltext stehen zusätzlich komplexe Regeln zum 'Heranrücken' und zu den 'Abstandsflächen' mit Maximalwerten in m² — diese sind hier nicht als separate Varianten erfasst.",
        ],
        "status": "inhalte_pruefen",
    },

    "bo-wien-para-79-abs4": {
        "headline_manuell": "Gartensiedlung / Kleingarten: Abstände nach gesonderten Regeln",
        "bedingungen": [{"parameter": "widmung", "operator": "ist", "wert": "gartensiedlungsgebiet"}],
        "status": "inhalte_pruefen",
    },

    "bo-wien-para-79-abs5": {
        "headline_manuell": "Gruppenbauweise: Abstände zu seitlichen Bauplatzgrenzen",
        "bedingungen": [{"parameter": "bauweise", "operator": "ist", "wert": "gruppe"}],
        "status": "inhalte_pruefen",
    },

    "bo-wien-para-79-abs6": {
        "headline_manuell": "Mehrere Gebäude auf einem Bauplatz: Abstände",
        "bedingungen": [{"typ": "immer"}],
        "pruefhinweise": ["PRÜFEN: Anwendbarkeit auf bestimmte Konstellationen im Originaltext prüfen."],
        "status": "inhalte_pruefen",
    },

    "bo-wien-para-79-abs6a": {
        "headline_manuell": "Schwimmbecken in gärtnerisch ausgestalteten Flächen: max. 60 m³",
        "bedingungen": [{"typ": "immer"}],
        "anforderung": {"typ": "prosa", "text": "Schwimmbecken bis 60 m³ Rauminhalt in gärtnerischen Flächen zulässig."},
        "pruefhinweise": ["PRÜFEN: Mindestabstand zu Nachbargrenzen im Originaltext verifizieren."],
        "status": "inhalte_pruefen",
    },

    "bo-wien-para-79-abs7": {
        "headline_manuell": "Gärtnerische Ausgestaltung von Abstandsflächen",
        "bedingungen": [{"typ": "immer"}],
        "status": "inhalte_pruefen",
    },

    "bo-wien-para-79-abs8": {
        "headline_manuell": "Garten-/Hofflächen als Versickerungsflächen",
        "bedingungen": [{"typ": "immer"}],
        "status": "inhalte_pruefen",
    },

    "bo-wien-para-79-abs9": {
        "headline_manuell": "Abstellflächen auf Abstandsflächen: Regeln und Ausnahmen",
        "bedingungen": [{"typ": "immer"}],
        "status": "inhalte_pruefen",
    },

    # =====================================================================
    # § 80 — BEBAUTE FLÄCHE (Definition)
    # =====================================================================

    "bo-wien-para-80-abs1": {
        "headline_manuell": "Definition: Bebaute Fläche als senkrechte Projektion des Gebäudes",
        "bedingungen": [{"typ": "immer"}],
        "anforderung": {"typ": "prosa", "text": "Bebaute Fläche = senkrechte Projektion inkl. Vorbauten."},
        "status": "inhalte_pruefen",
    },

    "bo-wien-para-80-abs2": {
        "headline_manuell": "Bebaute Fläche: Ausnahmen für bestimmte Bauteile",
        "bedingungen": [{"typ": "immer"}],
        "status": "inhalte_pruefen",
    },

    # =====================================================================
    # § 81 — GEBÄUDEHÖHE: BEMESSUNG
    # =====================================================================

    "bo-wien-para-81-abs1": {
        "headline_manuell": "Gebäudehöhe wird an Hauptfronten gemessen",
        "bedingungen": [{"typ": "immer"}],
        "querverweise": [
            {"ref_id": "bo-wien-para-75-abs2", "ref_text": "§ 75 Abs. 2", "beschreibung": "Zulässige Höhen je Bauklasse"}
        ],
        "status": "inhalte_pruefen",
    },

    "bo-wien-para-81-abs2": {
        "headline_manuell": "Mittlere Gebäudehöhe: Berechnungsmethode",
        "bedingungen": [{"typ": "immer"}],
        "pruefhinweise": ["PRÜFEN: Berechnungsmethode im Originaltext verifizieren."],
        "status": "inhalte_pruefen",
    },

    "bo-wien-para-81-abs3": {
        "headline_manuell": "Dachgeschoße und Dachausbauten: Anrechnung auf Gebäudehöhe",
        "bedingungen": [{"typ": "immer"}],
        "status": "inhalte_pruefen",
    },

    "bo-wien-para-81-abs4": {
        "headline_manuell": "Gebäudeumriss: Maximale Neigung / Abweichung von zulässiger Höhe",
        "bedingungen": [{"typ": "immer"}],
        "pruefhinweise": ["PRÜFEN: Detaillierte Regel zum Gebäudeumriss."],
        "status": "inhalte_pruefen",
    },

    "bo-wien-para-81-abs5": {
        "headline_manuell": "Dachneigung und Gebäudeumriss: Sonderregelungen",
        "bedingungen": [{"typ": "immer"}],
        "status": "inhalte_pruefen",
    },

    "bo-wien-para-81-abs6": {
        "headline_manuell": "Gebäudehöhe bei Hanglage",
        "bedingungen": [{"typ": "immer"}],
        "pruefhinweise": ["PRÜFEN: Hanglage ist derzeit kein Wizard-Parameter — ggf. ergänzen."],
        "status": "inhalte_pruefen",
    },

    "bo-wien-para-81-abs6a": {
        "headline_manuell": "Gebäudeumriss darf für Technik hocheffizienter Systeme überschritten werden",
        "bedingungen": [{"typ": "immer"}],
        "anforderung": {"typ": "prosa", "text": "Überschreitung im unbedingt erforderlichen Ausmaß zulässig."},
        "status": "inhalte_pruefen",
    },

    "bo-wien-para-81-abs7": {
        "headline_manuell": "Gartensiedlungsgebiete: Sondervorschriften zur Gebäudehöhe",
        "bedingungen": [{"parameter": "widmung", "operator": "ist", "wert": "gartensiedlungsgebiet"}],
        "status": "inhalte_pruefen",
    },

    "bo-wien-para-81-abs8": {
        "headline_manuell": "Überschreitung der Gebäudehöhe: Ausnahmefälle",
        "bedingungen": [{"typ": "immer"}],
        "status": "inhalte_pruefen",
    },

    # =====================================================================
    # § 82 — NEBENGEBÄUDE
    # =====================================================================

    "bo-wien-para-82-abs1": {
        "headline_manuell": "Nebengebäude: Definition und Grundregeln",
        "bedingungen": [{"typ": "immer"}],
        "anforderung": {"typ": "prosa", "text": "Nebengebäude: keine Hauptnutzung, gesondert in Erscheinung."},
        "status": "inhalte_pruefen",
    },

    "bo-wien-para-82-abs2": {
        "headline_manuell": "Nebengebäude: zulässige Höhe und Ausmaße",
        "bedingungen": [{"typ": "immer"}],
        "pruefhinweise": ["PRÜFEN: Spezifische Maße im Originaltext verifizieren."],
        "status": "inhalte_pruefen",
    },

    "bo-wien-para-82-abs3": {
        "headline_manuell": "Nebengebäude: Flächenbegrenzung",
        "bedingungen": [{"typ": "immer"}],
        "status": "inhalte_pruefen",
    },

    "bo-wien-para-82-abs4": {
        "headline_manuell": "Nebengebäude: Abstände zu Nachbargrenzen",
        "bedingungen": [{"typ": "immer"}],
        "status": "inhalte_pruefen",
    },

    "bo-wien-para-82-abs5": {
        "headline_manuell": "Nebengebäude im Gartensiedlungsgebiet",
        "bedingungen": [{"parameter": "widmung", "operator": "ist", "wert": "gartensiedlungsgebiet"}],
        "status": "inhalte_pruefen",
    },

    "bo-wien-para-82-abs6": {
        "headline_manuell": "Nebengebäude: Weitere Sonderregelungen",
        "bedingungen": [{"typ": "immer"}],
        "status": "inhalte_pruefen",
    },

    # =====================================================================
    # § 82a — TECHNISCHE INFRASTRUKTUR
    # =====================================================================

    "bo-wien-para-82a": {
        "headline_manuell": "Technikgebäude (z.B. Wärmepumpen): Erleichterungen für Nebengebäude",
        "bedingungen": [{"typ": "immer"}],
        "anforderung": {"typ": "prosa", "text": "Nur für technische Infrastruktur hocheffizienter Systeme."},
        "pruefhinweise": [
            "PRÜFEN: Mehrere Bedingungen (max. 1 Geschoß, keine Aufenthaltsräume, etc.) sind hier als Prosa zusammengefasst.",
        ],
        "status": "inhalte_pruefen",
    },

    # =====================================================================
    # § 83 — BAUTEILE VOR DER BAULINIE / STRASSENFLUCHTLINIE
    # =====================================================================

    "bo-wien-para-83-abs1": {
        "headline_manuell": "Zulässige Bauteil-Vorsprünge über Baulinie: Gesimse, Erker",
        "bedingungen": [{"parameter": "bauplatz_an_fluchtlinie", "operator": "ist", "wert": "ja"}],
        "status": "inhalte_pruefen",
    },

    "bo-wien-para-83-abs2": {
        "headline_manuell": "Weitere zulässige Vorsprünge: Details",
        "bedingungen": [{"parameter": "bauplatz_an_fluchtlinie", "operator": "ist", "wert": "ja"}],
        "status": "inhalte_pruefen",
    },

    "bo-wien-para-83-abs3": {
        "headline_manuell": "Einschränkungen für Vorsprünge",
        "bedingungen": [{"parameter": "bauplatz_an_fluchtlinie", "operator": "ist", "wert": "ja"}],
        "status": "inhalte_pruefen",
    },

    "bo-wien-para-83-abs4": {
        "headline_manuell": "Vorsprünge in Schutzzonen: Verschärfte Anforderungen",
        "bedingungen": [
            {"parameter": "bauplatz_an_fluchtlinie", "operator": "ist", "wert": "ja"},
            {"parameter": "in_schutzzone", "operator": "ist", "wert": "ja"},
        ],
        "status": "inhalte_pruefen",
    },

    "bo-wien-para-83-abs5": {
        "headline_manuell": "Vorsprünge: Maßnahmen für Verkehrssicherheit",
        "bedingungen": [{"parameter": "bauplatz_an_fluchtlinie", "operator": "ist", "wert": "ja"}],
        "status": "inhalte_pruefen",
    },

    # =====================================================================
    # § 84 — BAUTEILE IN ABSTANDSFLÄCHEN
    # =====================================================================

    "bo-wien-para-84-abs1": {
        "headline_manuell": "Zulässige Bauteile in Abstandsflächen, Vorgärten, Abständen",
        "bedingungen": [{"typ": "immer"}],
        "status": "inhalte_pruefen",
    },

    "bo-wien-para-84-abs2": {
        "headline_manuell": "Einschränkungen in Abstandsflächen",
        "bedingungen": [{"typ": "immer"}],
        "status": "inhalte_pruefen",
    },

    "bo-wien-para-84-abs3": {
        "headline_manuell": "Vorsprünge im Nachbarschutz",
        "bedingungen": [{"typ": "immer"}],
        "status": "inhalte_pruefen",
    },

    "bo-wien-para-84-abs4": {
        "headline_manuell": "Mindestabstände bei Nebenanlagen",
        "bedingungen": [{"typ": "immer"}],
        "anforderung": {"typ": "abstand", "min": 1.5, "einheit": "m", "bezug": "nachbargrenze"},
        "pruefhinweise": ["PRÜFEN: 1,5 m Mindestabstand ist Auszug, Originaltext hat weitere Details."],
        "status": "inhalte_pruefen",
    },

    # =====================================================================
    # § 85 — ÄUSSERE GESTALTUNG
    # =====================================================================

    "bo-wien-para-85-abs1": {
        "headline_manuell": "Äußeres der Bauwerke: Einfügung in Bauform, Maßstab, Werkstoff, Farbe",
        "bedingungen": [{"typ": "immer"}],
        "anforderung": {"typ": "prosa", "text": "Gestaltung darf nicht störend wirken."},
        "status": "inhalte_pruefen",
    },

    "bo-wien-para-85-abs2": {
        "headline_manuell": "Bauwerke in Schutzzonen / an Welterbe-Umgebung: Verschärfte Gestaltungsanforderungen",
        "bedingungen": [{"parameter": "in_schutzzone", "operator": "ist", "wert": "ja"}],
        "status": "inhalte_pruefen",
    },

    "bo-wien-para-85-abs3": {
        "headline_manuell": "Gestaltung bei bestehenden Bauwerken",
        "bedingungen": [{"parameter": "neubau_oder_bestand", "operator": "ist", "wert": "bestand"}],
        "status": "inhalte_pruefen",
    },

    "bo-wien-para-85-abs4": {
        "headline_manuell": "Farbgebung und Oberflächen",
        "bedingungen": [{"typ": "immer"}],
        "status": "inhalte_pruefen",
    },

    "bo-wien-para-85-abs5": {
        "headline_manuell": "Technische Aufbauten auf Dächern: Gestaltung",
        "bedingungen": [{"typ": "immer"}],
        "status": "inhalte_pruefen",
    },

    "bo-wien-para-85-abs6": {
        "headline_manuell": "Werbeeinrichtungen: Gestaltungsvorschriften",
        "bedingungen": [{"typ": "immer"}],
        "status": "inhalte_pruefen",
    },

    "bo-wien-para-85-abs7": {
        "headline_manuell": "Denkmalschutz: unberührt von Gestaltungsvorschriften der BO",
        "bedingungen": [{"typ": "immer"}],
        "status": "inhalte_pruefen",
    },

    # =====================================================================
    # § 86 — EINFRIEDUNGEN
    # =====================================================================

    "bo-wien-para-86-abs1": {
        "headline_manuell": "Einfriedungspflicht gegenüber Verkehrsflächen",
        "bedingungen": [{"typ": "immer"}],
        "status": "inhalte_pruefen",
    },

    "bo-wien-para-86-abs2": {
        "headline_manuell": "Zulässige Materialien und Gestaltung von Einfriedungen",
        "bedingungen": [{"typ": "immer"}],
        "status": "inhalte_pruefen",
    },

    "bo-wien-para-86-abs3": {
        "headline_manuell": "Einfriedungen im Vorgartenbereich: Durchblick erforderlich",
        "bedingungen": [{"typ": "immer"}],
        "pruefhinweise": ["PRÜFEN: Konkrete Maximalhöhe für Einfriedungen im Vorgarten im Originaltext."],
        "status": "inhalte_pruefen",
    },
}
