"""
Parser für Teil 8 der Bauordnung Wien.
Überführt den extrahierten Text in strukturiertes JSON gemäß Grid.legal-Schema.
"""
import re
import json
from pathlib import Path


# =============================================================================
# 1. TEXT EINLESEN UND NORMALISIEREN
# =============================================================================

def normalize_text(raw: str) -> str:
    """Entfernt Zeilenumbrüche und überflüssige Leerzeichen."""
    return re.sub(r'\s+', ' ', raw).strip()


def load_teil_8() -> str:
    """Lädt den bereits aufbereiteten Text von Teil 8."""
    with open('/home/claude/teil_8_clean.txt', 'r', encoding='utf-8') as f:
        return f.read()


# =============================================================================
# 2. PARAGRAPHEN-AUFTEILUNG
# =============================================================================

# Die Paragraphen-Überschriften (thematisch) stehen vor jedem §-Block
# und sind in der PDF als eigene Zeile hervorgehoben.
PARAGRAPH_UEBERSCHRIFTEN = {
    "75": "Bauklasseneinteilung, zulässige Gebäudehöhe",
    "76": "Bauweisen; bauliche Ausnützbarkeit",
    "77": "Strukturen (§ 77 - städtebauliche Sonderregelungen)",
    "78": "(entfallen)",
    "79": "Vorgärten, Abstandsflächen und gärtnerisch auszugestaltende Flächen",
    "80": "Bebaute Fläche",
    "81": "Gebäudehöhe und Gebäudeumrisse; Bemessung",
    "82": "Nebengebäude",
    "82a": "Nebengebäude für technische Infrastruktur",
    "83": "Bauteile vor der Baulinie oder Straßenfluchtlinie",
    "84": "Bauteile in Abstandsflächen, Vorgärten, Abständen",
    "85": "Äußere Gestaltung von Bauwerken",
    "86": "Einfriedungen",
}


def split_into_paragraphs(normalized_text: str) -> list[dict]:
    """Teilt den Text an §-Grenzen auf."""
    # Pattern: Findet alle Paragraphen-Anfänge (inkl. 'a'-Suffix, inkl. 'entfällt')
    para_pattern = re.compile(r'§\s+(\d+[a-z]?)\.\s+', re.UNICODE)
    matches = list(para_pattern.finditer(normalized_text))

    paragraphs = []
    for i, m in enumerate(matches):
        nummer = m.group(1)
        start = m.start()
        end = matches[i + 1].start() if i + 1 < len(matches) else len(normalized_text)
        body = normalized_text[m.end():end].strip()
        paragraphs.append({
            "nummer": nummer,
            "ueberschrift": PARAGRAPH_UEBERSCHRIFTEN.get(nummer, ""),
            "body": body,
        })
    return paragraphs


# =============================================================================
# 3. ABSATZ-AUFTEILUNG
# =============================================================================

def split_paragraph_into_absaetze(body: str) -> list[dict]:
    """Teilt einen Paragraphen in seine Absätze (1), (2), (3), ..."""
    # Wenn der Body mit "entfällt" anfängt, ist das ein Sonderfall
    if body.startswith("entfällt"):
        # Der Body enthält typisch: "entfällt; LGBl. Nr. X/YYYY vom D.M.YYYY" +
        # dann folgt evtl. eine fälschlich mit-normalisierte Überschrift des
        # nächsten Paragraphen. Schneide bei erster Datumsangabe ab.
        match = re.match(
            r'entfällt;\s*LGBl\.\s*Nr\.\s*\d+/\d+\s*vom\s*\d+\.\d+\.\d+',
            body
        )
        clean_text = match.group(0) if match else body.split('.')[0] + '.'
        return [{"nummer": None, "text": clean_text, "is_entfallen": True}]

    # Pattern: "(1)", "(2)", ... aber nicht "(§ 5 Abs. 4)"
    # Wir suchen (NUMMER) mit LÖSBAREM Zahlenbezug - einfachste Heuristik:
    # Absatz-Marker sind IMMER "(NUMMER)" am satzanfang
    absatz_pattern = re.compile(r'(?:^|\s)\((\d+[a-z]?)\)\s+', re.UNICODE)
    matches = list(absatz_pattern.finditer(body))

    if not matches:
        # Paragraphen ohne Absatzgliederung (z.B. § 82a)
        return [{"nummer": None, "text": body, "is_entfallen": False}]

    absaetze = []
    # Eventuell steht vor (1) noch Text - das wäre ungewöhnlich, ignoriere
    for i, m in enumerate(matches):
        nummer = m.group(1)
        start = m.end()
        end = matches[i + 1].start() if i + 1 < len(matches) else len(body)
        # Wenn nicht letzter: bis zum Beginn des nächsten Absatzes
        text = body[start:end].strip()
        absaetze.append({"nummer": nummer, "text": text, "is_entfallen": False})

    return absaetze


# =============================================================================
# 4. ZIFFERN-AUFTEILUNG (OPTIONAL, INNERHALB ABSATZ)
# =============================================================================

def split_absatz_into_ziffern(absatz_text: str) -> list[dict]:
    """
    Teilt einen Absatz optional in seine Ziffern auf, falls vorhanden.
    Ziffern: "1.", "2.", ... am Satzanfang
    Litera: "a)", "b)", ... am Satzanfang

    Für den ersten Wurf behandeln wir den ganzen Absatz als EIN Rechtssatz
    und legen die Ziffern-Aufteilung als Zukunftsschritt zur Seite.
    Das Aufteilen an "1." ist fehleranfällig, weil auch Maßzahlen wie
    "2,5 m" oder "§ 5 Abs. 1." so aussehen können.
    """
    return [{"text": absatz_text}]


# =============================================================================
# 5. LLM-PLATZHALTER GENERIEREN (HEADLINE + ERKLÄRUNG)
# =============================================================================

def generate_platzhalter_headline(absatz_text: str, paragraph_nummer: str,
                                   absatz_nummer: str | None) -> str:
    """
    Generiert eine kurze, architektengerechte Headline.
    Für den Prototyp extrahieren wir die ersten prägnanten Schlüsselaussagen.
    In einer echten Version würde das ein LLM-Call sein.
    """
    # Nimm die ersten ~90 Zeichen und kürze am letzten Wortende
    snippet = absatz_text[:90].strip()
    if len(absatz_text) > 90:
        # Schneide am letzten Leerzeichen
        last_space = snippet.rfind(' ')
        if last_space > 40:
            snippet = snippet[:last_space]
        snippet += " …"
    return f"[PLATZHALTER-HEADLINE] {snippet}"


def generate_platzhalter_erklaerung(absatz_text: str) -> str:
    """Generiert eine Architekten-gerechte Erklärung als Platzhalter."""
    return (
        "[PLATZHALTER-ERKLÄRUNG für Architekten] "
        "Diese Erklärung wird später durch eine LLM-generierte, "
        "architektengerechte Umformulierung der Vorschrift ersetzt. "
        "Sie soll praxistauglich erklären, was die Vorschrift für den "
        "Planungsalltag bedeutet und welche konkreten Konsequenzen sich "
        f"aus dem Originaltext ergeben. Der Originaltext umfasst {len(absatz_text)} Zeichen."
    )


# =============================================================================
# 6. KATEGORIE-MAPPING (AUS OUTPUT_STRUKTUR1.MD)
# =============================================================================

# Gemäß Briefing: Teil 8 fällt fast vollständig in Kategorie H
# (Bauplatz & Bebauung), mit Querverweisen zu anderen Kategorien
KATEGORIE_MAPPING = {
    # § 75 Bauklasseneinteilung/Gebäudehöhe → H.02
    "75": {"hauptkategorie": "H", "unterkategorie": "H.02",
           "label": "Gebäudehöhe & Geschoßanzahl"},
    # § 76 Bauweisen, bauliche Ausnützbarkeit → H.02 + H.01
    "76": {"hauptkategorie": "H", "unterkategorie": "H.02",
           "label": "Gebäudehöhe & Geschoßanzahl"},
    # § 77 Strukturen → H.01
    "77": {"hauptkategorie": "H", "unterkategorie": "H.01",
           "label": "Bebauungsbestimmungen & Widmung"},
    # § 78 entfallen → keine Kategorie
    "78": {"hauptkategorie": None, "unterkategorie": None, "label": None},
    # § 79 Vorgärten, Abstandsflächen → H.03
    "79": {"hauptkategorie": "H", "unterkategorie": "H.03",
           "label": "Abstände & Abstandsflächen"},
    # § 80 Bebaute Fläche → H.02
    "80": {"hauptkategorie": "H", "unterkategorie": "H.02",
           "label": "Gebäudehöhe & Geschoßanzahl"},
    # § 81 Gebäudehöhe Bemessung → H.02
    "81": {"hauptkategorie": "H", "unterkategorie": "H.02",
           "label": "Gebäudehöhe & Geschoßanzahl"},
    # § 82 Nebengebäude → H.02
    "82": {"hauptkategorie": "H", "unterkategorie": "H.02",
           "label": "Gebäudehöhe & Geschoßanzahl"},
    # § 82a Technische Infrastruktur → H.02
    "82a": {"hauptkategorie": "H", "unterkategorie": "H.02",
            "label": "Gebäudehöhe & Geschoßanzahl"},
    # § 83 Bauteile vor Baulinie → H.03
    "83": {"hauptkategorie": "H", "unterkategorie": "H.03",
           "label": "Abstände & Abstandsflächen"},
    # § 84 Bauteile in Abstandsflächen → H.03
    "84": {"hauptkategorie": "H", "unterkategorie": "H.03",
           "label": "Abstände & Abstandsflächen"},
    # § 85 Äußere Gestaltung → H.01
    "85": {"hauptkategorie": "H", "unterkategorie": "H.01",
           "label": "Bebauungsbestimmungen & Widmung"},
    # § 86 Einfriedungen → H.01
    "86": {"hauptkategorie": "H", "unterkategorie": "H.01",
           "label": "Bebauungsbestimmungen & Widmung"},
}


# =============================================================================
# 7. PLANUNGSPHASE-ZUORDNUNG
# =============================================================================

# Gemäß Briefing: je später die Phase, desto mehr Details.
# Bauliche Ausnützbarkeit (Höhe, Abstände, Bauklasse) sind VORENTWURF-Themen,
# da sie die grundsätzliche Gebäudekubatur bestimmen.
PLANUNGSPHASE_MAPPING = {
    "75": "vorentwurf",   # Bauklasse/Gebäudehöhe
    "76": "vorentwurf",   # Bauweisen
    "77": "vorentwurf",   # Strukturen
    "78": None,           # entfallen
    "79": "vorentwurf",   # Vorgärten/Abstände
    "80": "entwurf",      # Bebaute Fläche (Detailermittlung)
    "81": "entwurf",      # Gebäudehöhen-Bemessung
    "82": "entwurf",      # Nebengebäude
    "82a": "entwurf",     # Technische Infrastruktur
    "83": "entwurf",      # Bauteile vor Baulinie
    "84": "entwurf",      # Bauteile in Abstandsflächen
    "85": "entwurf",      # Äußere Gestaltung
    "86": "entwurf",      # Einfriedungen
}


# =============================================================================
# 8. RECHTSSATZ-OBJEKT ERZEUGEN
# =============================================================================

def build_rechtssatz(paragraph_nummer: str, absatz_nummer: str | None,
                     absatz_text: str, ueberschrift: str,
                     is_entfallen: bool = False) -> dict:
    """Erzeugt das JSON-Objekt für einen atomaren Rechtssatz."""
    suffix = f"-abs{absatz_nummer}" if absatz_nummer else ""
    rid = f"bo-wien-para-{paragraph_nummer}{suffix}"

    kat = KATEGORIE_MAPPING.get(paragraph_nummer, {})
    phase = PLANUNGSPHASE_MAPPING.get(paragraph_nummer)

    rechtssatz = {
        "id": rid,
        "quelle": "Bauordnung für Wien",
        "quelle_kurz": "BO Wien",
        "quelle_fassung": "11.03.2026",
        "paragraph": paragraph_nummer,
        "absatz": absatz_nummer,
        "ziffer": None,
        "fundstelle": (
            f"§ {paragraph_nummer}"
            + (f" Abs. {absatz_nummer}" if absatz_nummer else "")
        ),
        "paragraph_ueberschrift": ueberschrift,

        # Platzhalter für Output 1 (Nachschlagewerk)
        "headline": (
            generate_platzhalter_headline(absatz_text, paragraph_nummer, absatz_nummer)
            if not is_entfallen else "(Paragraph entfallen)"
        ),
        "erklaerung": (
            generate_platzhalter_erklaerung(absatz_text)
            if not is_entfallen else "Dieser Paragraph wurde aufgehoben."
        ),
        "originaltext": absatz_text,

        # Kategorisierung
        "hauptkategorie": kat.get("hauptkategorie"),
        "unterkategorie": kat.get("unterkategorie"),
        "unterkategorie_label": kat.get("label"),

        # Planungsphase für Dashboard (Output 2)
        "planungsphase": phase,

        # Bedingungen (später durch LLM oder manuell befüllt)
        "bedingungen": [],
        "anforderung": None,
        "querverweise": [],

        # Status-Flags
        "is_entfallen": is_entfallen,
        "status": "platzhalter_generiert",
    }
    return rechtssatz


# =============================================================================
# 9. MAIN - ZUSAMMENBAUEN
# =============================================================================

def main():
    raw = load_teil_8()
    normalized = normalize_text(raw)

    # Entferne alles vor dem ersten § (Teil-/Themen-Überschriften)
    first_para = re.search(r'§\s+\d+[a-z]?\.', normalized)
    if first_para:
        normalized = normalized[first_para.start():]

    paragraphen = split_into_paragraphs(normalized)

    rechtssaetze = []
    for p in paragraphen:
        absaetze = split_paragraph_into_absaetze(p["body"])
        for a in absaetze:
            rs = build_rechtssatz(
                paragraph_nummer=p["nummer"],
                absatz_nummer=a["nummer"],
                absatz_text=a["text"],
                ueberschrift=p["ueberschrift"],
                is_entfallen=a.get("is_entfallen", False),
            )
            rechtssaetze.append(rs)

    # Gesamtstruktur der Datei
    output = {
        "meta": {
            "quelle": "Bauordnung für Wien",
            "quelle_kurz": "BO Wien",
            "fassung": "11.03.2026",
            "teil_nummer": 8,
            "teil_titel": "Bauliche Ausnützbarkeit der Bauplätze",
            "paragraphen_range": "§§ 75–86",
            "anzahl_rechtssaetze": len(rechtssaetze),
            "generiert_von": "Grid.legal Parser v0.1",
            "hinweis": (
                "Headlines und Erklärungen sind Platzhalter und müssen "
                "vor Produktivsetzung durch LLM-Calls oder manuelle "
                "Redaktion ersetzt werden."
            ),
        },
        "paragraphen_uebersicht": [
            {
                "nummer": p["nummer"],
                "ueberschrift": p["ueberschrift"],
                "anzahl_absaetze": sum(
                    1 for rs in rechtssaetze if rs["paragraph"] == p["nummer"]
                ),
            }
            for p in paragraphen
        ],
        "rechtssaetze": rechtssaetze,
    }

    return output


if __name__ == "__main__":
    result = main()
    output_path = Path("/home/claude/bo-wien-teil-08.json")
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)

    print(f"✓ Datei geschrieben: {output_path}")
    print(f"  Paragraphen: {len(result['paragraphen_uebersicht'])}")
    print(f"  Rechtssätze: {len(result['rechtssaetze'])}")
    print("\n  Erster Rechtssatz:")
    print(json.dumps(result['rechtssaetze'][0], ensure_ascii=False, indent=2)[:1000])
