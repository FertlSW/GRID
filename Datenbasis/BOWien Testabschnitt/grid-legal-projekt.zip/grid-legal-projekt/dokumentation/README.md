# Grid.legal — Projekt-Wissensbasis

Dieses Verzeichnis enthält die strukturierten Gesetzestexte für das Tool **Grid.legal**.

## Was ist hier drin?

```
grid-legal-projekt/
│
├── gesetzestexte/              ← Alle Gesetzes-Quellen als JSON
│   └── bauordnung-wien/        ← Bauordnung für Wien
│       └── bo-wien-teil-08.json   (Teil 8 — Bauliche Ausnützbarkeit)
│
└── dokumentation/              ← Erklärungen, wie die Daten aufgebaut sind
    ├── README.md                  (diese Datei)
    └── SCHEMA.md                  (detaillierte Schema-Dokumentation)
```

## Was ist eine JSON-Datei?

Eine JSON-Datei ist eine strukturierte Textdatei, in der Informationen in **Karteikarten-Form** abgelegt sind. Jede Vorschrift aus dem Gesetz wird zu einem "Datensatz" mit festen Feldern. Du kannst JSON-Dateien mit jedem Texteditor öffnen, aber sie werden am lesbarsten, wenn du einen Editor mit JSON-Unterstützung verwendest (z.B. VS Code).

## Was steht in `bo-wien-teil-08.json`?

Diese Datei enthält den **8. Teil der Bauordnung Wien** (Paragraphen § 75 bis § 86) — das Kapitel "Bauliche Ausnützbarkeit der Bauplätze". Das sind unter anderem:

- Gebäudehöhen und Bauklassen (§ 75)
- Bauweisen (§ 76)
- Vorgärten und Abstandsflächen (§ 79)
- Bebaute Fläche (§ 80)
- Nebengebäude (§ 82)
- Äußere Gestaltung (§ 85)
- Einfriedungen (§ 86)

## Aufbau jeder JSON-Datei

Jede Gesetzestext-Datei hat drei Abschnitte:

### 1. `meta`
Kopfinformationen: Welche Gesetzesquelle, welche Fassung, welcher Teil, wie viele Rechtssätze enthalten sind.

### 2. `paragraphen_uebersicht`
Eine kurze Liste aller Paragraphen in diesem Teil — für schnelle Navigation.

### 3. `rechtssaetze`
Das Herzstück — eine Liste aller **einzelnen Rechtssätze**. Jeder Absatz eines Paragraphen wird zu einem eigenen Datensatz. So kann das Tool später gezielt einzelne Regeln ein- und ausblenden.

## Felder eines Rechtssatz-Datensatzes

| Feld | Bedeutung |
|---|---|
| `id` | Eindeutige Kennung, z.B. `bo-wien-para-75-abs1` |
| `quelle` | Volltitel der Gesetzesquelle |
| `quelle_kurz` | Kurzform, z.B. "BO Wien" |
| `paragraph` | Paragraph-Nummer, z.B. "75" |
| `absatz` | Absatz-Nummer, z.B. "2" oder `null` |
| `fundstelle` | Zitierform: "§ 75 Abs. 2" |
| `headline` | **Kurze Überschrift für Architekten** (aktuell Platzhalter) |
| `erklaerung` | **Architektengerechte Erklärung** (aktuell Platzhalter) |
| `originaltext` | Wortgetreuer Auszug aus dem Gesetz |
| `hauptkategorie` | Output-Kategorie (z.B. "H" = Bauplatz & Bebauung) |
| `unterkategorie` | Unterkategorie (z.B. "H.02" = Gebäudehöhe) |
| `planungsphase` | "vorentwurf" / "entwurf" / "genehmigung" / "ausfuehrung" |
| `bedingungen` | Wann gilt dieser Rechtssatz? (derzeit leer — wird später befüllt) |
| `anforderung` | Konkreter Schwellenwert, z.B. "max. 9 m" (derzeit leer) |
| `querverweise` | Links zu verwandten Vorschriften (derzeit leer) |
| `is_entfallen` | `true`, wenn dieser Paragraph aufgehoben wurde |
| `status` | Aktueller Bearbeitungsstand |

## Was ist noch zu tun? (Wichtig!)

**Die Felder `headline` und `erklaerung` sind aktuell Platzhalter.**
Sie enthalten automatisch generierte Beispieltexte. Sobald die JSON-Struktur steht und das UI funktioniert, müssen diese Felder mit echten, für Architekten optimierten Texten befüllt werden — entweder per LLM-Call oder manuell.

Die Felder `bedingungen`, `anforderung` und `querverweise` sind derzeit leer. Sie werden später befüllt, damit die Entscheidungsbaum-Engine die Rechtssätze anhand der Wizard-Eingaben filtern kann.

## Fassung und Aktualität

Die Datei basiert auf der Fassung der BO Wien vom **11.03.2026**. Bei Gesetzesnovellen muss die Datei neu generiert werden.

---

**Projekt**: Grid.legal
**Aktueller Stand**: UI-Prototyping-Phase, erster Teil der BO Wien strukturiert
